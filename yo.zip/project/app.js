
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');
var fs = require('fs');
var ejs = require('ejs');
var mysql = require('mysql');
var socketio = require('socket.io');
var util = require('util');
var grid = require('gridfs-stream');
var formidable = require('formidable');
// DB생성 및 스키마 설정
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test');

var Schema = mongoose.model('Schema', {id: String, pwd:String });
var se_product = mongoose.model('se_product',{pchoice: String, pname:String, pprice:Number, pcontent:String, pfilename:String, pclock:String});


var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.bodyParser());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', function(request,response){
  response.render('index');
});

app.post('/', function(request,response){
    var body = request.body;
    var memberId = body.id;
    var memberPwd = body.pwd;

    Schema.findOne({ id : memberId},function(error,id){
      if(id){
        var m_id = id.id;
        Schema.findOne({id : memberId, pwd : memberPwd},function(error,user){
          if(user){
            var c_id = user.id;
            var m_pwd = user.pwd;
            if(m_id==c_id)
            {
              se_product.find(function (err, products) {
                if (err) return handleError(err);
                response.render('success',{id : memberId, prod:products});
              });
            }else{
              response.render('pwdFaile');
            }
          }else{
              response.render('idFaile',{id : memberId});
          }
      });
    }
  });
});



app.post('/auction', function(request, response){
  /*이미지 저장*/
  fs.readFile(request.files.product_file.path, function (err, data) {
    var fileName = request.files.product_file.name;

    // var chioce = request.body.product_choice
    if(!fileName){
        response.end();
    } else {
        var Path = __dirname + "/public/data/" + fileName;
        fs.writeFile(Path, data, function (err) {
            response.end('Upload success');
        });
    }
  });

  /*데이터 베이스 저장*/
  var body = request.body;
  var product = se_product({pchoice:body.product_choice, pname:body.product_name, pprice:body.product_value, pcontent:body.product_contents, pfilename:request.files.product_file.name, pclock:body.clock});
  product.save(function(err){
    if(err){
      console.log(err);
    }else{
      se_product.find({}, function(err, docs) {
        if (!err){
          console.log(docs);
        } else {throw err;}
      },{_id:false});
    }
  });
  response.redirect('/');
});

app.get('/chat',function(request,response){
  response.render('chat');
})
app.get('/mychat',function(request,response){
  response.render('mychat');
})
app.get('/private',function(request,response){
  response.render('private');
})

app.get('/login', function(request,response){
  response.render('login');
});
app.post('/join', function(request,response){

  response.render('join');
});



app.post('/join2',function(request,response){
  var body = request.body;
  var memberId = body.id;

  Schema.findOne({ id : memberId },function(error,user){
    if(user){
  response.render('joinFaile',{ id:memberId });}
  else{
  var infor =  Schema({ id: body.id, pwd:body.pwd });
  infor.save(function (err) {
    if (err) {
      console.log(err);
    } else {
      console.log(infor);
    }
    response.redirect('/'); });
  }
});

});
var server = http.createServer(app);
server.listen(3000, function(){
  console.log('3000 Running');
});


var io = socketio.listen(server);
io.sockets.on('connection',function(socket){

socket.on('message_to_server',function(data){

  io.sockets.emit('message_to_front',data);
  });

  socket.on('join', function (data) {
          socket.join(data);
          socket.set('room', data);
      });

      // message 이벤트
    socket.on('p_message', function (data) {
    socket.get('room', function (error, room) {
    io.sockets.in(room).emit('p_message', data);
          });
      });
});
